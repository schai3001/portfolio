C&C Red Alert [Internet] (TrueType)
Version 1.001
Built 2007-12-14

Created by N3tRunn3r

_________________________
INFORMATION:
Do u know the Font of Command & Conquer: Red Alert v3.03 which is shown in the Internet lobby? No? Well... I created the popular Font for you!
This is a minifont or also called as pixelfont. Looks great in size 10 >> it is the original size like in the Red Alert Internet lobby.


HOW TO INSTALL:
After extracting the ttf file onto Desktop or into a new folder open Settings in the Start Menu of Windows, goto the Control Panel and double-click on the Fonts folder.
Just put or drag'n'drop the ttf file into the Fonts folder. That's all...


DISCLAIMER:
The Font in this zip file was created by me (N3tRunn3r).  All of my Fonts are Freeware, you can use them any way you want to (Personal use, Commercial use, or whatever).

If you have a Font related site and would like to offer my fonts on your site, go right ahead. All I ask is that you keep this text file intact with the Font.

You may not Sell or Distribute my Fonts for profit or alter them in any way without asking me first.

_________________________
If u want some updates of this Font or have some questions about it, contact me:
N3tRunn3r@hotmail.de

Have fun with it! And that's an order!  ;)

BEST REGARDS
N3tRunn3r